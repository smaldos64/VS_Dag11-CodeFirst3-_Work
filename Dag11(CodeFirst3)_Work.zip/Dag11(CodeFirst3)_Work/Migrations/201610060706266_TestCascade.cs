namespace Dag11_CodeFirst3__Work.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class TestCascade : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
